//Compile with -lm flag., run executable ./a.out 



#include<stdio.h>

#include<sys/sem.h>

#include<stdlib.h>

#include<math.h>

#include<sys/ipc.h>

#include<sys/shm.h>

#include<string.h>

#include<signal.h>

#include<sys/types.h>

#include<time.h>

#include <sys/time.h>



#define pi 180

#define d2r 3.141592654/180

#define key 555



#define sem(X,Y)	(X)*points+Y

#define matx(A,B)	mat[(A)*col+B]



char name[15],kil[150];



struct sembuf s_lock= {.sem_op=-2,.sem_flg=0};

struct sembuf s_ulock= {.sem_op=1,.sem_flg=0};



union semun {

        int val;                 /* Value for SETVAL */

        struct semid_ds *buf;    /* Buffer for IPC_STAT, IPC_SET */

        unsigned short  *array;  /* Array for GETALL, SETALL */

        struct seminfo  *__buf;  /* Buffer for IPC_INFO (Linux-specific) */

        };





int shmid,sz,semid;



void child_clean(int signo){;}



void intrrupt(int signo){



	sprintf(kil,"%s %s","pkill -9",name);

	semctl(semid,0,IPC_RMID);

	shmctl(shmid,IPC_RMID,NULL);

	system(kil);

	

}



struct sigaction act={.sa_handler=child_clean,.sa_flags=SA_NOCLDSTOP|SA_NOCLDWAIT},

		 act1={.sa_handler=intrrupt};





main(int argc,char *argv[]){



	FILE *fptr;

	int time1,points,sem_cnt;

	void *shmaddr;

	int n,i,j,row,col;

	double h,r,m,k,x,*mat;

	union semun arg;

        memset(&arg,0,sizeof(arg));

	

	if(argc != 3){

		printf("Usage: %s <points> <minutes>\n",argv[0]);

		exit(1);

		}



	strcpy(name,argv[0]+2);

	points = atoi(argv[1]);

	time1 = atoi(argv[2]);

	if(points<2 || time1<2){

		printf("Input: Error, min value:2\n");

		exit(8);

		}



	col = points+2;//incl., 0's

	n = points+1;

	h = 1/(double)n;

	k =1/(double)(2*n*n);			/*min*/

	r = k/(h * h);

	m = time1/(double)k;

	x = h; 

	time1 = 2*time1;

	row = time1+1;

	sem_cnt=(points)*(time1-1);

	short arr[sem_cnt];

	memset(arr,0,sizeof(arr));		/*sem_val=0*/

	arg.array=arr;

	if(sem_cnt>250 || sem_cnt<1){

		printf("semget: Maximum val of semaphore reached\n");

		exit(7);

		}



	sz = row*col*sizeof(double);

	sz = (sz/4096) ? (sz/4096)*4096 : 4096;



	if((shmid = shmget(key, sz, IPC_CREAT|0666)) < 0)

	{

		perror("shmget");

		exit(2);

	}







	shmaddr=shmat(shmid, NULL, 0);

	if(shmaddr == (void *)-1)

	{

		perror("shmat");

		exit(3);

	}



	memset(shmaddr, 0, sz);

	mat = shmaddr;

	

	fptr=fopen("./log","w");

	if(!fptr){

		perror("fopen");

		exit(8);

		}

	

	/*calc of first row*/



	for(i=1; i<=points; i++)

		mat[i]= 100 * sin(pi*d2r*x*i);



	semid = semget(key,sem_cnt, IPC_CREAT|IPC_EXCL|0666);

	if(semid == -1){

		perror("semget: Failed");

	        shmctl(shmid,IPC_RMID,NULL);

		exit(4);

		}

	

	if(semctl(semid,0,SETALL,arg)<0){

                perror("semctl");

		semctl(semid,0,IPC_RMID);

	        shmctl(shmid,IPC_RMID,NULL);

		exit(5);

		}



	for(i=0; i<row-2; i++){//add +1 to sema_val at boarder ele.

			s_ulock.sem_num=sem(i,0);

                        semop(semid,&s_ulock,1);

			s_ulock.sem_num=sem(i,points-1);			

                        semop(semid,&s_ulock,1);

			}

	i=j=1;

	int ka;

	sigaction(SIGCHLD,&act,NULL);

	sigaction(SIGINT,&act1,NULL);



	for(;i<=points;i++){

	

		if(!fork()){

			struct timeval tv;

			char tmb[50];

			gettimeofday(&tv,NULL);

			time_t tim=time(NULL);

			FILE *fptrc=fopen("./log","a+");

			if(!fptrc){

				perror("fopen");

				exit(9);

				}

			tmb[strlen(strcpy(tmb,ctime(&tim)+11))-6]='\0';

			fprintf(fptrc,"pid %u: Enter_time: %s.%lu\n",getpid(),tmb,tv.tv_usec);

		     for(ka=0;ka<time1;ka++,j++){			//monitoring column



			mat[j*col+i]=r*mat[(j-1)*col+(i-1)] + (1-2*r)*mat[(j-1)*col+i] + r*mat[(j-1)*col+(i+1)];



		//unlock

		

			if(i==1){

				s_ulock.sem_num=sem(j-1,i);

				semop(semid,&s_ulock,1);

				fprintf(fptrc,"pid %u: %d %s\n",getpid(),sem(j-1,i),"semaphore unlocked");

				

				}

			else if(i==points){

				s_ulock.sem_num=sem(j-1,i-2);

				semop(semid,&s_ulock,1);

				fprintf(fptrc,"pid %u: %d %s\n",getpid(),sem(j-1,i-2),"semaphore unlocked");

				}

			else {	

				s_ulock.sem_num=sem(j-1,i-2);

                        	semop(semid,&s_ulock,1);

				s_ulock.sem_num=sem(j-1,i);

                                semop(semid,&s_ulock,1);

				fprintf(fptrc,"pid %u: %d %s\n",getpid(),sem(j-1,i-2),"semaphore unlocked");

				fprintf(fptrc,"pid %u: %d %s\n",getpid(),sem(j-1,i),"semaphore unlocked");

				}

			



		//lock

			fprintf(fptrc,"pid %u: %d %s\n",getpid(),sem(j-1,i-1),"semaphore locked");

			s_lock.sem_num=sem(j-1,i-1);

			semop(semid,&s_lock,1);

			

			}

			//sleep(1);

			tim=time(NULL);

			tmb[strlen(strcpy(tmb,ctime(&tim)+11))-6]='\0';

			gettimeofday(&tv,NULL);

			fprintf(fptrc,"pid %u: Exit_time : %s.%lu\n",getpid(),tmb,tv.tv_usec);

			fclose(fptrc);

			return;

			} 

		else ;



		}



	wait(NULL);

	

	for(i=0,printf("\n"); i<row; i++,printf("\n")){

		printf("%0.1fmin| ",(float)(0.5*(i)));

		fflush(stdout);

		for(j=0; j<col; j++)

			printf("%8.4f ",mat[i*col+j]);

		}

	printf("\n");

	fclose(fptr);

	semctl(semid,0,IPC_RMID);

	shmctl(shmid,IPC_RMID,NULL);

}
